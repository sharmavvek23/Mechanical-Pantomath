<?php
	// Template Name: Without Sidebar
?>
<?php get_header(); ?>
	
	<!-- body wrapper START -->
	<div class="body-wrapper not-found">
		
		<!-- content with sidebar START -->
		<section class="section text-center">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<h1><?php esc_html_e( '404', 'trendy-pro' ); ?> <small><?php esc_html_e( 'Error, page not found!', 'trendy-pro' ); ?></small></h1>
						<p><?php esc_html_e( 'Why not try a search, or go back to homepage.', 'trendy-pro' ); ?></p>
						<?php get_search_form( $echo = true ); ?>
						<a class="btn btn-primary" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Go To Homepage', 'trendy-pro' ); ?></a>
					</div>
				</div>
			</div>
		</section>
		<!-- content with sidebar END -->
		
	</div>
	<!-- body wrapper END -->
	
<?php get_footer(); ?>