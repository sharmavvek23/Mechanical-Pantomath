<?php
/**
 * Created by PhpStorm.
 * User: venkat
 * Date: 2/5/16
 * Time: 4:32 PM           
 */

include_once( get_template_directory() . '/admin/kirki/kirki.php' );     
include_once( get_template_directory() . '/admin/kirki-helpers/class-newgenn-kirki.php' );
       
Newgenn_Kirki::add_config( 'newgenn', array(     
	'capability'    => 'edit_theme_options',                  
	'option_type'   => 'theme_mod',          
) );             
     
// newgenn option start //   

//  site identity section // 

Newgenn_Kirki::add_section( 'title_tagline', array(
	'title'          => __( 'Site Identity','newgenn' ),
	'description'    => __( 'Site Header Options', 'newgenn'),       
	'priority'       => 8,         																																																					
) );

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'logo_title',
	'label'    => __( 'Enable Logo as Title', 'newgenn' ),
	'section'  => 'title_tagline',
	'type'     => 'switch',
	'priority' => 5,
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' )
	),
	'default'  => 'off',   
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'tagline',
	'label'    => __( 'Show site Tagline', 'newgenn' ), 
	'section'  => 'title_tagline',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' )
	),
	'default'  => 'on',
) );

// home panel //

Newgenn_Kirki::add_panel( 'home_options', array(     
	'title'       => __( 'Home', 'newgenn' ),
	'description' => __( 'Home Page Related Options', 'newgenn' ),     
) );  

// home page type section

Newgenn_Kirki::add_section( 'home_type_section', array(
	'title'          => __( 'General Settings','newgenn' ),
	'description'    => __( 'Home Page options', 'newgenn'),
	'panel'          => 'home_options', // Not typically needed. 
) );

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'enable_home_default_content',
	'label'    => __( 'Enable Home Page Default Content', 'newgenn' ),
	'section'  => 'home_type_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' ) 
	),
	'default'  => 'off',
	'tooltip' => __('Enable home page default content ( home page content )','newgenn'),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'home_sidebar',
	'label'    => __( 'Enable sidebar on the Home page', 'newgenn' ),
	'section'  => 'home_type_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' )
	),
	'default'  => 'off',
	'tooltip' => __('Disable by default. If you want to display the sidebars in your frontpage, turn this Enable.','newgenn'),
) ); 

// Slider section

Newgenn_Kirki::add_section( 'slider_section', array(
	'title'          => __( 'Slider Section','newgenn' ),
	'description'    => __( 'Home Page Slider Related Options', 'newgenn'),
	'panel'          => 'home_options', // Not typically needed. 
) );
Newgenn_Kirki::add_field( 'newgenn', array(  
	'settings' => 'enable_slider',
	'label'    => __( 'Enable Slider Post ( Section )', 'newgenn' ),
	'section'  => 'slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' ),
	),
	'default'  => 'on',
	
	'tooltip' => __('Enable Slider Post in home page','newgenn'),
) );

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'slider_cat',
	'label'    => __( 'Slider Posts category', 'newgenn' ),
	'section'  => 'slider_section',
	'type'     => 'select',
	'choices' => Kirki_Helper::get_terms( 'category' ),
	'active_callback' => array(
		array(
			'setting'  => 'enable_slider',
			'operator' => '==',
			'value'    => true,
		),
    ),
    'tooltip' => __('Create post ( Goto Dashboard => Post => Add New ) and Post Featured Image ( Preferred size is 1200 x 450 pixels ) as taken as slider image and Post Content as taken as Flexcaption.','newgenn'),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'slider_count',
	'label'    => __( 'No. of Sliders', 'newgenn' ),
	'section'  => 'slider_section',
	'type'     => 'number',
	'choices' => array(
		'min' => 1,
		'max' => 999,
		'step' => 1,
	),
	'default'  => 2,
	'active_callback' => array(
		array(
			'setting'  => 'enable_slider',
			'operator' => '==',
			'value'    => true,
		),
    ),
    'tooltip' => __('Enter number of slides you want to display under your selected Category','newgenn'),
) );


// service section 

Newgenn_Kirki::add_section( 'service_section', array(
	'title'          => __( 'Service Section','newgenn' ),
	'description'    => __( 'Home Page - Service Related Options', 'newgenn'),
	'panel'          => 'home_options', // Not typically needed. 
) );

Newgenn_Kirki::add_field( 'newgenn', array( 
	'settings' => 'enable_service',
	'label'    => __( 'Enable Service Section', 'newgenn' ),
	'section'  => 'service_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' ) 
	),
	
	'default'  => 'on',
	'tooltip' => __('Enable service section in home page','newgenn'),
) ); 
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'service_count',
	'label'    => __( 'No. of Service Section', 'newgenn' ),
	'description' => __('Save the Settings, and Reload this page to Configure the service section','newgenn'),
	'section'  => 'service_section',
	'type'     => 'number',
	'choices' => array(
		'min' => 4,
		'max' => 99, 
	),
	'default'  => 4,
	'active_callback' => array(
		array(
			'setting'  => 'enable_service',
			'operator' => '==',
			'value'    => true,
		),
		
    ),
    'tooltip' => __('Enter number of service page you want to display','newgenn'),
) );

if ( get_theme_mod('service_count') > 0 ) {
 $service = get_theme_mod('service_count');
 		for ( $i = 1 ; $i <= $service ; $i++ ) {
             //Create the settings Once, and Loop through it.
 			Newgenn_Kirki::add_field( 'newgenn', array(
				'settings' => 'service_'.$i,
				'label'    => sprintf(__( 'Service Section #%1$s', 'newgenn' ), $i ),
				'section'  => 'service_section',
				'type'     => 'dropdown-pages',	
				//'tooltip' => __('Create Page ( Goto Dashboard => Page =>Add New ) and Page Featured Image ( Preferred size is 100 x 100 pixels )','newgenn'),
				'active_callback' => array(
					array(
						'setting'  => 'enable_service',
						'operator' => '==',
						'value'    => true,
					),
					
                ), 
               // 'description' => __('Create Page ( Goto Dashboard => Page =>Add New ) and Page Featured Image ( Preferred size is 100 x 100 pixels )','newgenn'),
        
			) );
 		}
}
// latest blog section 

Newgenn_Kirki::add_section( 'latest_blog_section', array(
	'title'          => __( 'Latest Blog Section','newgenn' ),
	'description'    => __( 'Home Page - Latest Blog Options', 'newgenn'),
	'panel'          => 'home_options', // Not typically needed. 
) );

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'enable_recent_post_service',
	'label'    => __( 'Enable Recent Post Section', 'newgenn' ),
	'section'  => 'latest_blog_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' ) 
	),
	
	'default'  => 'on',
	'tooltip' => __('Enable recent post section in home page','newgenn'),
) );

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'recent_posts_count',
	'label'    => __( 'No. of Recent Posts', 'newgenn' ),
	'section'  => 'latest_blog_section',
	'type'     => 'number',
	'choices' => array(
		'min' => 3,
		'max' => 99,
		'step' => 1,
	),
	'default'  => 3,
	'active_callback' => array(
		array(
			'setting'  => 'enable_recent_post_service',
			'operator' => '==',
			'value'    => true,
		),
		
    ),
) );

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'recent_posts_exclude', 
	'label'    => __( 'Exclude the Posts from Home Page. Post IDs, separated by commas', 'newgenn' ),
	'section'  => 'latest_blog_section',
	'type'     => 'text',
	'active_callback' => array(
		array(
			'setting'  => 'enable_recent_post_service',
			'operator' => '==',
			'value'    => true,
		),
		
    ),
) );


// general panel   

Newgenn_Kirki::add_panel( 'general_panel', array(   
	'title'       => __( 'General Settings', 'newgenn' ),  
	'description' => __( 'general settings', 'newgenn' ),         
) );

//  Page title bar section // 

Newgenn_Kirki::add_section( 'header-pagetitle-bar', array(   
	'title'          => __( 'Page Title Bar & Breadcrumb','newgenn' ),
	'description'    => __( 'Page Title bar related options', 'newgenn'),
	'panel'          => 'general_panel', // Not typically needed.
) );

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'page_titlebar',  
	'label'    => __( 'Page Title Bar', 'newgenn' ),
	'section'  => 'header-pagetitle-bar', 
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		1 => __( 'Show Bar and Content', 'newgenn' ),
		2 => __( 'Show Content Only ', 'newgenn' ),
		3 => __('Hide','newgenn'),
    ),
    'default' => 1,
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'page_titlebar_text',  
	'label'    => __( 'Page Title Bar Text', 'newgenn' ),
	'section'  => 'header-pagetitle-bar', 
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		1 => __( 'Show', 'newgenn' ),
		2 => __( 'Hide', 'newgenn' ), 
    ),
    'default' => 1,
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'breadcrumb',  
	'label'    => __( 'Breadcrumb', 'newgenn' ),
	'section'  => 'header-pagetitle-bar', 
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' ),
	),
	'default'  => 'on',
) ); 

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'breadcrumb_char',
	'label'    => __( 'Breadcrumb Character', 'newgenn' ),
	'section'  => 'header-pagetitle-bar',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		1 => __( ' >> ', 'newgenn' ),
		2 => __( ' / ', 'newgenn' ),
		3 => __( ' > ', 'newgenn' ),
	),
	'default'  => 1,
	'active_callback' => array(
		array(
			'setting'  => 'breadcrumb',
			'operator' => '==',
			'value'    => true,
		),
	),
	//'sanitize_callback' => 'allow_htmlentities'
) );

//  pagination section // 

Newgenn_Kirki::add_section( 'general-pagination', array(   
	'title'          => __( 'Pagination','newgenn' ),
	'description'    => __( 'Pagination related options', 'newgenn'),
	'panel'          => 'general_panel', // Not typically needed.
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'numeric_pagination',
	'label'    => __( 'Numeric Pagination', 'newgenn' ),   
	'section'  => 'general-pagination',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Numbered', 'newgenn' ),
		'off' => esc_attr__( 'Next/Previous', 'newgenn' )
	),
	'default'  => 'on',
) );

// skin color panel 

Newgenn_Kirki::add_panel( 'skin_color_panel', array(   
	'title'       => __( 'Skin Color', 'newgenn' ),  
	'description' => __( 'Color Settings', 'newgenn' ),         
) );

// Change Color Options

Newgenn_Kirki::add_section( 'primary_color_field', array(
	'title'          => __( 'Change Color Options','newgenn' ),
	'description'    => __( 'This will reflect in links, buttons,Navigation and many others. Choose a color to match your site.', 'newgenn'),
	'panel'          => 'skin_color_panel', // Not typically needed.
) );

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'enable_primary_color',
	'label'    => __( 'Enable Custom Primary color', 'newgenn' ),
	'section'  => 'primary_color_field',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' )
	),
	'default'  => 'off',
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'primary_color',
	'label'    => __( 'Primary color', 'newgenn' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#EC1D23',
	"choices"  => array(
		'alpha' => true,
	),
	'active_callback' => array(
		array (
			'setting'  => 'enable_primary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element'  => 'button,.home .site-content #primary .services-wrapper div::after,.site-footer .scroll-to-top,.site-footer .scroll-to-top:hover,
							input[type="button"],.page-template-blog-fullwidth .entry-body a.more-link,
							.page-template-blog-large .entry-body a.more-link,
							.archive.category .entry-body a.more-link ,.widget_tag_cloud a:hover,
							input[type="reset"],.widget_calendar table caption,
							input[type="submit"],.webulous_page_navi li.bpn-next-link a,.home .site-content #primary .services-wrapper div h1, .home .site-content #primary .services-wrapper div h2, .home .site-content #primary .services-wrapper div h3, .home .site-content #primary .services-wrapper div h5, .home .site-content #primary .services-wrapper div h6 ,.post-wrapper .latest-post a.btn-readmore:hover,
							.webulous_page_navi li.bpn-prev-link a,.hentry.sticky,blockquote,blockquote:before,.flexslider ol.flex-control-paging li a.flex-active,.services,.main-navigation .current_page_item a, .main-navigation .current-menu-item a, .main-navigation .current-menu-parent > a, .main-navigation .current_page_parent > a,.main-navigation ul.nav-menu > li > a:hover,.main-navigation ul.nav-menu > li li a:hover,.home .site-content #primary .services-wrapper .more-link:hover',
			'property' => 'background-color',
		),
		array(
			'element'  => '.top-nav ul li:hover a,a,.footer-bottom .widget_nav_menu a:hover,.footer-bottom p a,.entry-header .header-entry-meta,.site-footer .footer-widgets a:hover,.widget-area ul li a:hover ,.widget_calendar table th a, .widget_calendar table td a,
							.entry-body .header-entry-meta,.entry-header .entry-title-meta span:hover,.widget-area .widget_rss a,
							.entry-body .entry-title-meta span:hover,.entry-header .entry-title-meta a:hover,
							.entry-body .entry-title-meta a:hover,.breadcrumb-wrap #breadcrumb a,.post-wrapper .latest-post h5 a:hover,.page-links a,.hentry.post h1 a:hover,.branding .site-branding h1.site-title a:hover, .comment-metadata a:hover,.navigation a:hover, .more-link:hover, .comment-navigation a:hover,.nav-links a:hover .meta-nav',
			'property' => 'color',
		),
		array(
			'element' => '.webulous_page_navi li.bpn-current,.widget-area h4.widget-title,.site-footer .footer-widgets h4.widget-title ',
			'property' => 'border-bottom-color',
		),
		array(
			'element' => '.navigation a:hover, .more-link:hover, .comment-navigation a:hover ',
			'property' => 'border-color',
		),
		array(
			'element' => '.widget-area h4.widget-title:after ',
			'property' => 'border-left-color',
		),
	),
) );

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'enable_nav_bg_color',
	'label'    => __( 'Enable Navigation Bar BG Color', 'newgenn' ),
	'section'  => 'primary_color_field',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' )
	),
	'default'  => 'off',
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'nav_bg_color',
	'label'    => __( 'Navigation Bar BG Color', 'newgenn' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#030303',
	'choices'  => array(
	    'alpha' => true,
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_nav_bg_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element' => '.nav-wrap',
			'property' => 'background-color',
		),
	),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'enable_nav_hover_color',
	'label'    => __( 'Enable Navigation Hover color', 'newgenn' ),
	'section'  => 'primary_color_field',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' )
	),
	'default'  => 'off',
) );    
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'nav_hover_color',
	'label'    => __( 'Navigation Hover Color', 'newgenn' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#ec1d23',
	'choices'  => array(
	    'alpha' => true,
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_nav_hover_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element' => '.main-navigation .current_page_item > a,.main-navigation .current-menu-item > a, .main-navigation .current_page_ancestor > a,.main-navigation ul.nav-menu > li a:hover,.current-menu-parent,.main-navigation .current_page_parent > a,.main-navigation .current_page_item a, .main-navigation .current-menu-item a, .main-navigation .current-menu-parent > a,
						 .main-navigation .current_page_parent > a',
			'property' => 'background-color',
		),
		array(
			'element' => '.main-navigation a:hover::after',
			'property' => 'border-left-color',
		),
	),
) );
newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'enable_dd_hover_color',
	'label'    => __( 'Enable Custom Navigation Dropdown Hover color ', 'newgenn' ),
	'section'  => 'primary_color_field',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' )
	),
	'default'  => 'off',
) );
newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'dd_hover_color',
	'label'    => __( 'Navigation Dropdown Hover Color', 'newgenn' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '',
	'choices'  => array(
	    'alpha' => true,
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_dd_hover_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		
		array(
			'element' => '.nav-wrap .main-navigation ul li .sub-menu li a:hover,.main-navigation .sub-menu .current_page_item > a, 
						.main-navigation .sub-menu .current-menu-item > a, .main-navigation .sub-menu .current_page_ancestor > a, 
						.main-navigation .children .current_page_item > a, .main-navigation .children .current-menu-item > a,
						.main-navigation .children .current_page_ancestor > a,.main-navigation .sub-menu li a:hover, 
						.main-navigation .children li a:hover',
			'property' => 'background-color',
		),
       array(
			'element' => '.main-navigation .sub-menu .current_page_item > a,
			              .main-navigation .children .current_page_item >a',
			'property' => 'color',
			'media_query' => '@media(max-width: 600px)',
		),
	),
) );
// typography panel //

Newgenn_Kirki::add_panel( 'typography', array( 
	'title'       => __( 'Typography', 'newgenn' ),
	'description' => __( 'Typography and Link Color Settings', 'newgenn' ),
) );
   
    Newgenn_Kirki::add_section( 'typography_section', array(
		'title'          => __( 'General Settings','newgenn' ),
		'description'    => __( 'General Settings', 'newgenn'),
		'panel'          => 'typography', // Not typically needed.
	) );
	Newgenn_Kirki::add_field( 'newgenn', array(
		'settings' => 'custom_typography',
		'label'    => __( 'Enable Custom Typography', 'newgenn' ),
		'description' => __('Save the Settings, and Reload this page to Configure the typography section','newgenn'),
		'section'  => 'typography_section',
		'type'     => 'switch',
		'choices' => array(
			'on'  => esc_attr__( 'Enable', 'newgenn' ),
			'off' => esc_attr__( 'Disable', 'newgenn' )
		),
		'tooltip' => __('Turn on to customize typography and turn off for default typography','newgenn'),
		'default'  => 'off',
	) );

$typography_setting = get_theme_mod('custom_typography',false );
if( $typography_setting ) :

        $body_font = get_theme_mod('body_family','Open Sans');		        
	    $body_color = get_theme_mod( 'body_color','#030303' );   
		$body_size = get_theme_mod( 'body_size','16');
		$body_weight = get_theme_mod( 'body_weight','regular');
		$body_weight == 'bold' ? $body_weight = '400':  $body_weight = 'regular';
		

	Newgenn_Kirki::add_section( 'body_font', array(
		'title'          => __( 'Body Font','newgenn' ),
		'description'    => __( 'Specify the body font properties', 'newgenn'),
		'panel'          => 'typography', // Not typically needed.
	) ); 


	Newgenn_Kirki::add_field( 'newgenn', array(
		'settings' => 'body',
		'label'    => __( 'Body Settings', 'newgenn' ),
		'section'  => 'body_font', 
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $body_font,
			'variant'        => $body_weight,
			'font-size'      => $body_size.'px',
			'line-height'    => '1.5',
			'letter-spacing' => '0',
			'color'          => $body_color,
		),
		'output'      => array(
			array(
				'element' => 'body',
				//'suffix' => '!important',
			),
		),
	) );


	Newgenn_Kirki::add_section( 'heading_section', array(
		'title'          => __( 'Heading Font','newgenn' ),
		'description'    => __( 'Specify typography of H1, H2, H3, H4, H5, H6', 'newgenn'),
		'panel'          => 'typography', // Not typically needed.
	) );
	

	$h1_font = get_theme_mod('h1_family','Raleway');
	$h1_color = get_theme_mod( 'h1_color','#030303' );
	$h1_size = get_theme_mod( 'h1_size','42');
	$h1_weight = get_theme_mod( 'h1_weight','700');
	$h1_weight == 'bold' ? $h1_weight = '700' : $h1_weight = 'regular';

	Newgenn_Kirki::add_field( 'newgenn', array(
		'settings' => 'h1',
		'label'    => __( 'H1 Settings', 'newgenn' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $h1_font,
			'variant'        => $h1_weight,
			'font-size'      => $h1_size.'px',
			'line-height'    => '1.5',
			'letter-spacing' => '0',
			'color'          => $h1_color,
		),
		'output'      => array(
			array(
				'element' => 'h1',
			),
		),
		
	) );

	$h2_font = get_theme_mod('h2_family','Raleway');
	$h2_color = get_theme_mod( 'h2_color','#030303' );
	$h2_size = get_theme_mod( 'h2_size','36');
	$h2_weight = get_theme_mod( 'h2_weight','700');
	$h2_weight == 'bold' ? $h2_weight = '700' : $h2_weight = 'regular';

	Newgenn_Kirki::add_field( 'newgenn', array(
		'settings' => 'h2',
		'label'    => __( 'H2 Settings', 'newgenn' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $h2_font,
			'variant'        => $h2_weight,
			'font-size'      => $h2_size.'px',
			'line-height'    => '1.5',
			'letter-spacing' => '0',
			'color'          => $h2_color,
		),
		'output'      => array(
			array(
				'element' => 'h2',
			),
		),
		
	) );

	$h3_font = get_theme_mod('h3_family','Raleway');
	$h3_color = get_theme_mod( 'h3_color','#030303' );
	$h3_size = get_theme_mod( 'h3_size','30');
	$h3_weight = get_theme_mod( 'h3_weight','700');
	$h3_weight == 'bold' ? $h3_weight = '700' : $h3_weight = 'regular';

	Newgenn_Kirki::add_field( 'newgenn', array(
		'settings' => 'h3',
		'label'    => __( 'H3 Settings', 'newgenn' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default' => array(
			'font-family'    => $h3_font,
			'variant'        => $h3_weight,
			'font-size'      => $h3_size.'px',
			'line-height'    => '1.5',
			'letter-spacing' => '0',
			'color'          => $h3_color,
		),
		'output'      => array(
			array(
				'element' => 'h3',
			),
		),
	
	) );

	$h4_font = get_theme_mod('h4_family','Raleway');
	$h4_color = get_theme_mod( 'h4_color','#030303' );
	$h4_size = get_theme_mod( 'h4_size','24');
	$h4_weight = get_theme_mod( 'h4_weight','700');
	$h4_weight == 'bold' ? $h4_weight = '700' : $h4_weight = 'regular';


	Newgenn_Kirki::add_field( 'newgenn', array(
		'settings' => 'h4',
		'label'    => __( 'H4 Settings', 'newgenn' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $h4_font,
			'variant'        => $h4_weight,
			'font-size'      => $h4_size.'px',
			'line-height'    => '1.5',
			'letter-spacing' => '0',
			'color'          => $h4_color,
		),
		'output'      => array(
			array(
				'element' => 'h4',
			),
		),
		
	) );

    $h5_font = get_theme_mod('h5_family','Raleway');
	$h5_color = get_theme_mod( 'h5_color','#030303' );
	$h5_size = get_theme_mod( 'h5_size','18');
	$h5_weight = get_theme_mod( 'h5_weight','700');
	$h5_weight == 'bold' ? $h5_weight = '700' : $h5_weight = 'regular';


	Newgenn_Kirki::add_field( 'newgenn', array(
		'settings' => 'h5',
		'label'    => __( 'H5 Settings', 'newgenn' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $h5_font,
			'variant'        => $h5_weight,
			'font-size'      => $h5_size.'px',
			'line-height'    => '1.5',
			'letter-spacing' => '0',
			'color'          => $h5_color,
		),
		'output'      => array(
			array(
				'element' => 'h5',
			),
		),
		
	) );

	$h6_font = get_theme_mod('h6_family','Raleway');
	$h6_color = get_theme_mod( 'h6_color','#030303' );
	$h6_size = get_theme_mod( 'h6_size','16');
	$h6_weight = get_theme_mod( 'h6_weight','700');
	$h6_weight == 'bold' ? $h6_weight = '700' : $h6_weight = 'regular';


	Newgenn_Kirki::add_field( 'newgenn', array(
		'settings' => 'h6',
		'label'    => __( 'H6 Settings', 'newgenn' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $h6_font,
			'variant'        => $h6_weight,
			'font-size'      => $h6_size.'px',
			'line-height'    => '1.5',
			'letter-spacing' => '0',
			'color'          => $h6_color,
		),
		'output'      => array(
			array(
				'element' => 'h6',
			),
		),
		
	) );

	// navigation font 
	Newgenn_Kirki::add_section( 'navigation_section', array(
		'title'          => __( 'Navigation Font','newgenn' ),
		'description'    => __( 'Specify Navigation font properties', 'newgenn'),
		'panel'          => 'typography', // Not typically needed.
	) );

	Newgenn_Kirki::add_field( 'newgenn', array(
		'settings' => 'navigation_font',
		'label'    => __( 'Navigation Font Settings', 'newgenn' ),
		'section'  => 'navigation_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => 'Open Sans',
			'variant'        => '600',
			'font-size'      => '16px',
			'line-height'    => '1.8', 
			'letter-spacing' => '0',
			'color'          => '#ffffff',
		),
		'output'      => array(
			array(
				'element' => '.main-navigation a',
			),
		),
	) );
endif; 


// header panel //

Newgenn_Kirki::add_panel( 'header_panel', array(     
	'title'       => __( 'Header', 'newgenn' ),
	'description' => __( 'Header Related Options', 'newgenn' ), 
) );  

Newgenn_Kirki::add_section( 'header', array(
	'title'          => __( 'General Header','newgenn' ),
	'description'    => __( 'Header options', 'newgenn'),
	'panel'          => 'header_panel', // Not typically needed.  
) );    

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'header_text_color',
	'label'    => __( 'Header Text Color', 'newgenn' ),
	'section'  => 'header',
	'type'     => 'color',
	'choices'  => array(
	    'alpha' => true,
	),
	'default'  => '', 
	'output'   => array(
		array(
			'element'  => '.main-navigation a,.site-header .branding .site-branding .site-title a,.main-navigation ul ul a,.main-navigation a:hover, .main-navigation .current_page_item > a, .main-navigation .current-menu-item > a, .main-navigation .current-menu-parent > a, .main-navigation .current_page_ancestor > a, .main-navigation .current_page_parent > a',
			'property' => 'color',
		),
	),
) );
/*Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'header_search',
	'label'    => __( 'Enable to Show Search box in Header', 'newgenn' ), 
	'section'  => 'header',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' )
	),
	'default'  => 'on',
) );*/
/* Breaking News section  */
/*Newgenn_Kirki::add_section( 'header_breaking_news', array(
	'title'          => __( 'Breaking News','newgenn' ),
	'description'    => __( 'Breaking News', 'newgenn'),
	'panel'          => 'header_panel', // Not typically needed.
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'header_breaking_news',
	'label'    => __( 'Enable Breaking News', 'newgenn' ), 
	'section'  => 'header_breaking_news',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' )
	),
	'active_callback' => array(
		array(
			'setting'  => 'home-page-type',
			'operator' => '==',
			'value'    => 'magazine',
		),
    ),
	'default'  => 'off',
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'header_breaking_news_title',
	'label'    => __( 'Breaking News Title', 'newgenn' ),
	'section'  => 'header_breaking_news',
	'type'     => 'text',
	'active_callback' => array(
		array(
			'setting'  => 'home-page-type', 
			'operator' => '==',
			'value'    => 'magazine',
		),
		array(
			'setting'  => 'header_breaking_news', 
			'operator' => '==',
			'value'    => true,
		),
    ),
    'default' => __('LATEST NEWS','newgenn'),   
) );*/
/* STICKY HEADER section */   

Newgenn_Kirki::add_section( 'stricky_header', array(
	'title'          => __( 'Sticky Menu','newgenn' ),
	'description'    => __( 'sticky header', 'newgenn'),
	'panel'          => 'header_panel', // Not typically needed.
) );
Newgenn_Kirki::add_field( 'newgenn', array(    
	'settings' => 'sticky_header',
	'label'    => __( 'Enable Sticky Header', 'newgenn' ),
	'section'  => 'stricky_header',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' )
	),
	'default'  => 'off',
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'sticky_header_position',
	'label'    => __( 'Enable Sticky Header Position', 'newgenn' ),
	'section'  => 'stricky_header',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'top'  => esc_attr__( 'Top', 'newgenn' ),
		'bottom' => esc_attr__( 'Bottom', 'newgenn' )
	),
	'active_callback'    => array(
		array(
			'setting'  => 'sticky_header',
			'operator' => '==',
			'value'    => true,
		),
	),
	'default'  => 'top',
) );

Newgenn_Kirki::add_section( 'scroll_to_top', array(
	'title'          => __( 'Scroll to Top','newgenn' ),
	'description'    => __( 'Scroll to Top Button', 'newgenn'),
	'panel'          => 'header_panel', // Not typically needed.
) );
Newgenn_Kirki::add_field( 'newgenn', array(    
	'settings' => 'scroll_to_top_button',
	'label'    => __( 'Enable Scroll to Top', 'newgenn' ),
	'section'  => 'scroll_to_top',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' )
	),
	'default'  => 'on',
) );

/*
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'header_top_margin',
	'label'    => __( 'Header Top Margin', 'newgenn' ),
	'description' => __('Select the top margin of header in pixels','newgenn'),
	'section'  => 'header',
	'type'     => 'number',
	'choices' => array(
		'min' => 1,
		'max' => 1000,
		'step' => 1,
	),
	//'default'  => '213',
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'header_bottom_margin',
	'label'    => __( 'Header Bottom Margin', 'newgenn' ),
	'description' => __('Select the bottom margin of header in pixels','newgenn'),
	'section'  => 'header',
	'type'     => 'number',
	'choices' => array(
		'min' => 1,
		'max' => 1000,
		'step' => 1,
	),
	//'default'  => '213',
) );*/

Newgenn_Kirki::add_section( 'header_image', array(
	'title'          => __( 'Header Background Image & Video','newgenn' ),
	'description'    => __( 'Custom Header Image & Video options', 'newgenn'),
	'panel'          => 'header_panel', // Not typically needed.  
) );

Newgenn_Kirki::add_field( 'newgenn', array(   
	'settings' => 'header_bg_size',
	'label'    => __( 'Header Background Size', 'newgenn' ),
	'section'  => 'header_image',
	'type'     => 'radio-buttonset', 
    'choices' => array(
		'cover'  => esc_attr__( 'Cover', 'newgenn' ),
		'contain' => esc_attr__( 'Contain', 'newgenn' ),
		'auto'  => esc_attr__( 'Auto', 'newgenn' ),
		'inherit'  => esc_attr__( 'Inherit', 'newgenn' ),
	),
	'output'   => array(
		array(
			'element'  => '.site-header',
			'property' => 'background-size',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'header_image',
			'operator' => '!=',
			'value'    => 'remove-header',
		),
	),
	'default'  => 'cover',
	'tooltip' => __('Header Background Image Size','newgenn'),
) );

/*Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'header_height',
	'label'    => __( 'Header Background Image Height', 'newgenn' ),
	'section'  => 'header_image',
	'type'     => 'number',
	'choices' => array(
		'min' => 100,
		'max' => 600,
		'step' => 1,
	),
	'default'  => '213',
) ); */
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'header_bg_repeat',
	'label'    => __( 'Header Background Repeat', 'newgenn' ),
	'section'  => 'header_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'no-repeat' => esc_attr__('No Repeat', 'newgenn'),
        'repeat' => esc_attr__('Repeat', 'newgenn'),
        'repeat-x' => esc_attr__('Repeat Horizontally','newgenn'),
        'repeat-y' => esc_attr__('Repeat Vertically','newgenn'),
	),
	'output'   => array(
		array(
			'element'  => '.site-header',
			'property' => 'background-repeat',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'header_image',
			'operator' => '!=',
			'value'    => 'remove-header',
		),
	),
	'default'  => 'repeat',  
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'header_bg_position', 
	'label'    => __( 'Header Background Position', 'newgenn' ),
	'section'  => 'header_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'center top' => esc_attr__('Center Top', 'newgenn'),
        'center center' => esc_attr__('Center Center', 'newgenn'),
        'center bottom' => esc_attr__('Center Bottom', 'newgenn'),
        'left top' => esc_attr__('Left Top', 'newgenn'),
        'left center' => esc_attr__('Left Center', 'newgenn'),
        'left bottom' => esc_attr__('Left Bottom', 'newgenn'),
        'right top' => esc_attr__('Right Top', 'newgenn'),
        'right center' => esc_attr__('Right Center', 'newgenn'),
        'right bottom' => esc_attr__('Right Bottom', 'newgenn'),
	),
	'output'   => array(
		array(
			'element'  => '.site-header',
			'property' => 'background-position',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'header_image',
			'operator' => '!=',
			'value'    => 'remove-header',
		),
	),
	'default'  => 'center center',  
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'header_bg_attachment',
	'label'    => __( 'Header Background Attachment', 'newgenn' ),
	'section'  => 'header_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'scroll' => esc_attr__('Scroll', 'newgenn'),
        'fixed' => esc_attr__('Fixed', 'newgenn'),
	),
	'output'   => array(
		array(
			'element'  => '.site-header',
			'property' => 'background-attachment',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'header_image',
			'operator' => '!=',
			'value'    => 'remove-header',
		),
	),
	'default'  => 'scroll',  
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'header_overlay',
	'label'    => __( 'Enable Header( Background ) Overlay', 'newgenn' ),
	'section'  => 'header_image',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' )
	),
	'default'  => 'off',
) );
  
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'header_overlay_color',
	'label'    => __( 'Header Overlay ( Background )color', 'newgenn' ),
	'section'  => 'header_image',
	'type'     => 'color',
	'choices'  => array(
	    'alpha' => true,
	),
	'default'  => '#E5493A', 
	'output'   => array(
		array(
			'element'  => '.overlay-header',
			'property' => 'background-color', 
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'header_overlay',
			'operator' => '==',
			'value'    => true,
		),
	),
) );

/*
/* e-option start */
/*
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'custon_favicon',
	'label'    => __( 'Custom Favicon', 'newgenn' ),
	'section'  => 'header',
	'type'     => 'upload',
	'default'  => '',
) ); */
/* e-option start */ 
/* Blog page section */


/* Blog panel */

Newgenn_Kirki::add_panel( 'blog_panel', array(     
	'title'       => __( 'Blog', 'newgenn' ),
	'description' => __( 'Blog Related Options', 'newgenn' ),     
) ); 
Newgenn_Kirki::add_section( 'blog', array(
	'title'          => __( 'Blog Page','newgenn' ),
	'description'    => __( 'Blog Related Options', 'newgenn'),
	'panel'          => 'blog_panel', // Not typically needed.
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'blog-slider',
	'label'    => __( 'Enable to show the slider on blog page', 'newgenn' ),
	'section'  => 'blog',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' ) 
	),
	'default'  => 'off',
	'tooltip' => __('To show the slider on posts page','newgenn'),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'blog_slider_cat',
	'label'    => __( 'Blog Slider Posts category', 'newgenn' ),
	'section'  => 'blog',
	'type'     => 'select',
	'choices' => Kirki_Helper::get_terms( 'category' ),
	'active_callback' => array(
		array(
			'setting'  => 'blog-slider',
			'operator' => '==',
			'value'    => true,
		),
    ),
    'tooltip' => __('Create post ( Goto Dashboard => Post => Add New ) and Post Featured Image ( Preferred size is 1200 x 450 pixels ) as taken as slider image and Post Content as taken as Flexcaption.','newgenn'),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'blog_slider_count',
	'label'    => __( 'No. of Sliders', 'newgenn' ),
	'section'  => 'blog',
	'type'     => 'number',
	'choices' => array(
		'min' => 1,
		'max' => 999,
		'step' => 1,
	),
	'default'  => 2,
	'active_callback' => array(
		array(
			'setting'  => 'blog-slider',
			'operator' => '==',
			'value'    => true,
		),
    ),
    'tooltip' => __('Enter number of slides you want to display under your selected Category','newgenn'),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'blog_layout',
	'label'    => __( 'Select Blog Page Layout you prefer', 'newgenn' ),
	'section'  => 'blog',
	'type'     => 'select',
	'multiple'  => 1,
	'choices' => array(
		1  => esc_attr__( 'Default ( One Column )', 'newgenn' ),
		2 => esc_attr__( 'Two Columns ', 'newgenn' ),
		3 => esc_attr__( 'Three Columns ( Without Sidebar ) ', 'newgenn' ),
		4 => esc_attr__( 'Two Columns With Masonry', 'newgenn' ),
		5 => esc_attr__( 'Three Columns With Masonry ( Without Sidebar ) ', 'newgenn' ),
	),
	'default'  => 1,
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'featured_image',
	'label'    => __( 'Enable Featured Image', 'newgenn' ),
	'section'  => 'blog',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' ) 
	),
	'default'  => 'on',
	'tooltip' => __('Enable Featured Image for blog page','newgenn'),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'more_text',
	'label'    => __( 'More Text', 'newgenn' ),
	'section'  => 'blog',
	'type'     => 'text',
	'description' => __('Text to display in case of text too long','newgenn'),
	'default' => __('Read More','newgenn'),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'featured_image_size',
	'label'    => __( 'Choose the Featured Image Size for Blog Page', 'newgenn' ),
	'section'  => 'blog',
	'type'     => 'select',
	'multiple'  => 1,
	'choices' => array(
		1 => esc_attr__( 'Large Featured Image', 'newgenn' ),
		2 => esc_attr__( 'Small Featured Image', 'newgenn' ),
		3 => esc_attr__( 'Original Size', 'newgenn' ),
		4 => esc_attr__( 'Medium', 'newgenn' ),
		5 => esc_attr__( 'Large', 'newgenn' ), 
	),
	'default'  => 1,
	'active_callback' => array(
		array(
			'setting'  => 'featured_image',
			'operator' => '==',
			'value'    => true,
		),
    ),
    'tooltip' => __('Set large and medium image size: Goto Dashboard => Settings => Media', 'newgenn') ,
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'enable_single_post_top_meta',
	'label'    => __( 'Enable to display top post meta data', 'newgenn' ),
	'section'  => 'blog',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' ) 
	),
	'default'  => 'on',
	'tooltip' => __('Enable to Display Top Post Meta Details. This will reflect for blog page, single blog page, blog full width & blog large templates','newgenn'),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'single_post_top_meta',
	'label'    => __( 'Activate and Arrange the Order of Top Post Meta elements', 'newgenn' ),
	'section'  => 'blog',
	'type'     => 'sortable',
	'choices'     => array(
		1 => esc_attr__( 'date', 'newgenn' ),
		2 => esc_attr__( 'author', 'newgenn' ),
		3 => esc_attr__( 'comment', 'newgenn' ),
		4 => esc_attr__( 'category', 'newgenn' ),
		5 => esc_attr__( 'tags', 'newgenn' ),
		6 => esc_attr__( 'edit', 'newgenn' ),
	),
	'default'  => array(1, 2, 6),
	'active_callback' => array(
		array(
			'setting'  => 'enable_single_post_top_meta',
			'operator' => '==',
			'value'    => true,
		),
    ),
    'tooltip' => __('Click above eye icon in order to activate the field, This will reflect for blog page, single blog page, blog full width & blog large templates','newgenn'),

) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'enable_single_post_bottom_meta',
	'label'    => __( 'Enable to display bottom post meta data', 'newgenn' ),
	'section'  => 'blog', 
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' ) 
	),
	'tooltip' => __('Enable to Display Top Post Meta Details. This will reflect for blog page, single blog page, blog full width & blog large templates','newgenn'),
	'default'  => 'on',
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'single_post_bottom_meta',
	'label'    => __( 'Activate and arrange the Order of Bottom Post Meta elements', 'newgenn' ),
	'section'  => 'blog',
	'type'     => 'sortable',
	'choices'     => array(
		1 => esc_attr__( 'date', 'newgenn' ),
		2 => esc_attr__( 'author', 'newgenn' ),
		3 => esc_attr__( 'comment', 'newgenn' ),
		4 => esc_attr__( 'category', 'newgenn' ),
		5 => esc_attr__( 'tags', 'newgenn' ),
		6 => esc_attr__( 'edit', 'newgenn' ),
	),
	'default'  => array(3,4,5),
	'active_callback' => array(
		array(
			'setting'  => 'enable_single_post_bottom_meta',
			'operator' => '==',
			'value'    => true,
		),
    ),
    'tooltip' => __('Click above eye icon in order to activate the field, This will reflect for blog page, single blog page, blog full width & blog large templates','newgenn'),
) );


/* Single Blog page section */

Newgenn_Kirki::add_section( 'single_blog', array(
	'title'          => __( 'Single Blog Page','newgenn' ),
	'description'    => __( 'Single Blog Page Related Options', 'newgenn'),
	'panel'          => 'blog_panel', // Not typically needed.
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'single_featured_image',
	'label'    => __( 'Enable Single Post Featured Image', 'newgenn' ),
	'section'  => 'single_blog',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' ) 
	),
	'default'  => 'on',
	'tooltip' => __('Enable Featured Image for Single Post Page','newgenn'),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'single_featured_image_size',
	'label'    => __( 'Choose the featured image display type for Single Post Page', 'newgenn' ),
	'section'  => 'single_blog',
	'type'     => 'radio',
	'choices' => array(
		1  => esc_attr__( 'Large Featured Image', 'newgenn' ),
		2 => esc_attr__( 'Small Featured Image', 'newgenn' ),
		3 => esc_attr__( 'FullWidth Featured Image', 'newgenn' ),
	),
	'default'  => 1,
	'active_callback' => array(
		array(
			'setting'  => 'single_featured_image',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'author_bio_box',
	'label'    => __( 'Enable Author Bio Box below single post', 'newgenn' ),
	'section'  => 'single_blog',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' ) 
	),
	'default'  => 'off',
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'social_sharing_box',
	'label'    => __( 'Enable Social Sharing options Box below single post', 'newgenn' ),
	'section'  => 'single_blog',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' ) 
	),
	'default'  => 'on',  
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'related_posts',
	'label'    => __( 'Show Related Posts', 'newgenn' ),
	'section'  => 'single_blog',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' ) 
	),
	'default'  => 'off',
	'tooltip' => __('Show the Related Post for Single Blog Page','newgenn'),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'related_posts_hierarchy',
	'label'    => __( 'Related Posts Must Be Shown As:', 'newgenn' ),
	'section'  => 'single_blog',
	'type'     => 'radio',
	'choices' => array(
		1  => esc_attr__( 'Related Posts By Tags', 'newgenn' ),
		2 => esc_attr__( 'Related Posts By Categories', 'newgenn' ) 
	),
	'default'  => 1,
	'active_callback' => array(
		array(
			'setting'  => 'related_posts',
			'operator' => '==',
			'value'    => true,
		),
    ),
    'tooltip' => __('Select the Hierarchy','newgenn'),

) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'comments',
	'label'    => __( ' Show Comments', 'newgenn' ),
	'section'  => 'single_blog',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' ) 
	),
	'default'  => 'on',
	'tooltip' => __('Show the Comments for Single Blog Page','newgenn'),
) );

//  social network panel //

newgenn_Kirki::add_panel( 'social_panel', array(
	'title'        =>__( 'Social Networks', 'newgenn'),
	'description'  =>__( 'social networks', 'newgenn'),
	'priority'  =>11,	
));

//social sharing box section

newgenn_Kirki::add_section( 'social_sharing_box', array(
	'title'          =>__( 'Social Sharing Box', 'newgenn'),
	'description'   =>__('Social Sharing box related options', 'newgenn'),
	'panel'			 =>'social_panel',
));

newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'facebook_sb',
	'label'    => __( 'Enable facebook sharing option below single post', 'newgenn' ),
	'section'  => 'social_sharing_box',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' ) 
	),
	'default'  => 'on',
) );
newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'twitter_sb',
	'label'    => __( 'Enable twitter sharing option below single post', 'newgenn' ),
	'section'  => 'social_sharing_box',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' ) 
	),
	'default'  => 'on',
) );
newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'linkedin_sb',
	'label'    => __( 'Enable linkedin sharing option below single post', 'newgenn' ),
	'section'  => 'social_sharing_box',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' ) 
	),
	'default'  => 'on',
) );
newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'google-plus_sb',
	'label'    => __( 'Enable googleplus sharing option below single post', 'newgenn' ),
	'section'  => 'social_sharing_box',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' ) 
	),
	'default'  => 'on',
) );

newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'email_sb',
	'label'    => __( 'Enable email sharing option below single post', 'newgenn' ),
	'section'  => 'social_sharing_box',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' ) 
	),
	'default'  => 'on',
) );

/* FOOTER SECTION 
footer panel */

Newgenn_Kirki::add_panel( 'footer_panel', array(     
	'title'       => __( 'Footer', 'newgenn' ),
	'description' => __( 'Footer Related Options', 'newgenn' ),     
) );  

Newgenn_Kirki::add_section( 'footer', array(
	'title'          => __( 'Footer','newgenn' ),
	'description'    => __( 'Footer related options', 'newgenn'),
	'panel'          => 'footer_panel', // Not typically needed.
) );

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'footer_widgets',
	'label'    => __( 'Footer Widget Area', 'newgenn' ),
	'description' => sprintf(__('Select widgets, Goto <a href="%1$s"target="_blank"> Customizer </a> => Widgets','newgenn'),admin_url('customize.php') ),
	'section'  => 'footer',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' ) 
	),
	'default'  => 'on',
) );
/* Choose No.Of Footer area */
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'footer_widgets_count',
	'label'    => __( 'Choose No.of widget area you want in footer', 'newgenn' ),
	'section'  => 'footer',
	'type'     => 'radio-buttonset',
	'choices' => array(
		1  => esc_attr__( '1', 'newgenn' ),
		2  => esc_attr__( '2', 'newgenn' ),
		3  => esc_attr__( '3', 'newgenn' ),
		4  => esc_attr__( '4', 'newgenn' ), 
	),
	'default'  => 4,
) );

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'copyright',
	'label'    => __( 'Footer Copyright Text', 'newgenn' ),
	'section'  => 'footer',
	'type'     => 'textarea',
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'footer_top_margin',
	'label'    => __( 'Footer Top Margin', 'newgenn' ),
	'description' => __('Select the top margin of footer in pixels','newgenn'),
	'section'  => 'footer',
	'type'     => 'number',
	'choices' => array(
		'min' => 1,
		'max' => 1000,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.site-footer',
			'property' => 'margin-top',
			'units' => 'px',
		),
	),
	'default'  => 0,
) );

/* CUSTOM FOOTER BACKGROUND IMAGE 
footer background image section  */

Newgenn_Kirki::add_section( 'footer_image', array(
	'title'          => __( 'Footer Image','newgenn' ),
	'description'    => __( 'Custom Footer Image options', 'newgenn'),
	'panel'          => 'footer_panel', // Not typically needed.
) );

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'footer_bg_image',
	'label'    => __( 'Upload Footer Background Image', 'newgenn' ),
	'section'  => 'footer_image',
	'type'     => 'upload',
	'default'  => '',
	'output'   => array(
		array(
			'element'  => '.footer-image,.site-footer .footer-bottom',
			'property' => 'background-image',
		),
	),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'footer_bg_size',
	'label'    => __( 'Footer Background Size', 'newgenn' ),
	'section'  => 'footer_image',
	'type'     => 'radio-buttonset',
    'choices' => array(
		'cover'  => esc_attr__( 'Cover', 'newgenn' ),
		'contain' => esc_attr__( 'Contain', 'newgenn' ),
		'auto'  => esc_attr__( 'Auto', 'newgenn' ),
		'inherit'  => esc_attr__( 'Inherit', 'newgenn' ),
	),
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-size',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'footer_bg_image',
			'operator' => '=',
			'value'    => true,
		),
	),
	'default'  => 'cover',
	'tooltip' => __('Footer Background Image Size','newgenn'),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'footer_bg_repeat',
	'label'    => __( 'Footer Background Repeat', 'newgenn' ),
	'section'  => 'footer_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'no-repeat' => esc_attr__('No Repeat', 'newgenn'),
        'repeat' => esc_attr__('Repeat', 'newgenn'),
        'repeat-x' => esc_attr__('Repeat Horizontally','newgenn'),
        'repeat-y' => esc_attr__('Repeat Vertically','newgenn'),
	),
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-repeat',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'footer_bg_image',
			'operator' => '=',
			'value'    => true,
		),
	),
	'default'  => 'repeat',  
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'footer_bg_position',
	'label'    => __( 'Footer Background Position', 'newgenn' ),
	'section'  => 'footer_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'center top' => esc_attr__('Center Top', 'newgenn'),
        'center center' => esc_attr__('Center Center', 'newgenn'),
        'center bottom' => esc_attr__('Center Bottom', 'newgenn'),
        'left top' => esc_attr__('Left Top', 'newgenn'),
        'left center' => esc_attr__('Left Center', 'newgenn'),
        'left bottom' => esc_attr__('Left Bottom', 'newgenn'),
        'right top' => esc_attr__('Right Top', 'newgenn'),
        'right center' => esc_attr__('Right Center', 'newgenn'),
        'right bottom' => esc_attr__('Right Bottom', 'newgenn'),
	),
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-position',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'footer_bg_image',
			'operator' => '=',
			'value'    => true,
		),
	),
	'default'  => 'center center',  
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'footer_bg_attachment',
	'label'    => __( 'Footer Background Attachment', 'newgenn' ),
	'section'  => 'footer_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'scroll' => esc_attr__('Scroll', 'newgenn'),
        'fixed' => esc_attr__('Fixed', 'newgenn'),
	),
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-attachment',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'footer_bg_image',
			'operator' => '=',
			'value'    => true,
		),
	),
	'default'  => 'scroll',  
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'footer_overlay',
	'label'    => __( 'Enable Footer( Background ) Overlay', 'newgenn' ),
	'section'  => 'footer_image',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' )
	),
	'default'  => 'off',
) );
  
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'footer_overlay_color',
	'label'    => __( 'Footer Overlay ( Background )color', 'newgenn' ),
	'section'  => 'footer_image',
	'type'     => 'color',
	'choices'  => array(
	    'alpha' => true,
	),
	'default'  => '', 
	'active_callback' => array(
		array(
			'setting'  => 'footer_overlay',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output'   => array(
		array(
			'element'  => '.footer-overlay',
			'property' => 'background-color',
			'suffix' => '!important'
		),
	),
) );


// single page section //

Newgenn_Kirki::add_section( 'single_page', array(
	'title'          => __( 'Single Page','newgenn' ),
	'description'    => __( 'Single Page Related Options', 'newgenn'),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'single_page_featured_image',
	'label'    => __( 'Enable Single Page Featured Image', 'newgenn' ),
	'section'  => 'single_page',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' ) 
	),
	'default'  => 'on',
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'single_page_featured_image_size',
	'label'    => __( 'Single Page Featured Image Size', 'newgenn' ),
	'section'  => 'single_page',
	'type'     => 'radio-buttonset',
	'choices' => array(
		1  => esc_attr__( 'Normal', 'newgenn' ),
		2 =>  esc_attr__( 'FullWidth', 'newgenn' ),
	),
	'default'  => 1,
	'active_callback' => array(
		array(
			'setting'  => 'single_page_featured_image',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );

// Layout section //

Newgenn_Kirki::add_section( 'layout', array(
	'title'          => __( 'Layout','newgenn' ),
	'description'    => __( 'Layout Related Options', 'newgenn'),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'site-style',
	'label'    => __( 'Site Style', 'newgenn' ),
	'section'  => 'layout',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'wide' =>  esc_attr__('Wide', 'newgenn'),
        'boxed' =>  esc_attr__('Boxed', 'newgenn'),
        'fluid' =>  esc_attr__('Fluid', 'newgenn'),  
        //'static' =>  esc_attr__('Static ( Non Responsive )', 'newgenn'),
    ),
	'default'  => 'wide',
	'tooltip' => __('Select the default site layout. Defaults to "Wide".','newgenn'),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'sidebar_position',
	'label'    => __( 'Main Layout', 'newgenn' ),
	'section'  => 'layout',
	'type'     => 'radio-image',   
	'description' => __('Select main content and sidebar arrannewgennent.','newgenn'),
	'choices' => array(
		'left' =>  get_template_directory_uri() . '/admin/kirki/assets/images/2cl.png',
        'right' =>  get_template_directory_uri() . '/admin/kirki/assets/images/2cr.png',
        'two-sidebar' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cm.png',  
        'two-sidebar-left' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cl.png',
        'two-sidebar-right' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cr.png',
        'fullwidth' =>  get_template_directory_uri() . '/admin/kirki/assets/images/1c.png',
        'no-sidebar' =>  get_template_directory_uri() . '/images/no-sidebar.png',
    ),
	'default'  => 'right',
	'tooltip' => __('This layout will be reflected in all pages unless unique layout template is set for specific page','newgenn'),
) );

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'body_top_margin',
	'label'    => __( 'Body Top Margin', 'newgenn' ),
	'description' => __('Select the top margin of body element in pixels','newgenn'),
	'section'  => 'layout',
	'type'     => 'number',
	'choices' => array(
		'min' => 0,
		'max' => 200,
		'step' => 1,
	),
	'active_callback'    => array(
		array(
			'setting'  => 'site-style',
			'operator' => '==',
			'value'    => 'boxed',
		),
	),
	'output'   => array(
		array(
			'element'  => 'body',
			'property' => 'margin-top',
			'units'    => 'px',
		),
	),
	'default'  => 0,
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'body_bottom_margin',
	'label'    => __( 'Body Bottom Margin', 'newgenn' ),
	'description' => __('Select the bottom margin of body element in pixels','newgenn'),
	'section'  => 'layout',
	'type'     => 'number',
	'choices' => array(
		'min' => 0,
		'max' => 200,
		'step' => 1,
	),
	'active_callback'    => array(
		array(
			'setting'  => 'site-style',
			'operator' => '==',
			'value'    => 'boxed',
		),
	),
	'output'   => array(
		array(
			'element'  => 'body',
			'property' => 'margin-bottom',
			'units'    => 'px',
		),
	),
	'default'  => 0,
) );

/* LAYOUT SECTION  */
/*
Newgenn_Kirki::add_section( 'layout', array(
	'title'          => __( 'Layout','newgenn' ),   
	'description'    => __( 'Layout settings that affects overall site', 'newgenn'),
	'panel'          => 'newgenn_options', // Not typically needed.
) );



Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'primary_sidebar_width',
	'label'    => __( 'Primary Sidebar Width', 'newgenn' ),
	'section'  => 'layout',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'1' => __( 'One Column', 'newgenn' ),
		'2' => __( 'Two Column', 'newgenn' ),
		'3' => __( 'Three Column', 'newgenn' ),
		'4' => __( 'Four Column', 'newgenn' ),
		'5' => __( 'Five Column ', 'newgenn' ),
	),
	'default'  => '5',  
	'tooltip' => __('Select the width of the Primary Sidebar. Please note that the values represent grid columns. The total width of the page is 16 columns, so selecting 5 here will make the primary sidebar to have a width of approximately 1/3 ( 4/16 ) of the total page width.','newgenn'),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'secondary_sidebar_width',
	'label'    => __( 'Secondary Sidebar Width', 'newgenn' ),
	'section'  => 'layout',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'1' => __( 'One Column', 'newgenn' ),
		'2' => __( 'Two Column', 'newgenn' ),
		'3' => __( 'Three Column', 'newgenn' ),
		'4' => __( 'Four Column', 'newgenn' ),
		'5' => __( 'Five Column ', 'newgenn' ),
	),            
	'default'  => '5',  
	'tooltip' => __('Select the width of the Secondary Sidebar. Please note that the values represent grid columns. The total width of the page is 16 columns, so selecting 5 here will make the primary sidebar to have a width of approximately 1/3 ( 4/16 ) of the total page width.','newgenn'),
) ); 

*/

/* FOOTER SECTION 
footer panel */

Newgenn_Kirki::add_panel( 'footer_panel', array(     
	'title'       => __( 'Footer', 'newgenn' ),
	'description' => __( 'Footer Related Options', 'newgenn' ),     
) );  

Newgenn_Kirki::add_section( 'footer', array(
	'title'          => __( 'Footer','newgenn' ),
	'description'    => __( 'Footer related options', 'newgenn'),
	'panel'          => 'footer_panel', // Not typically needed.
) );

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'footer_widgets',
	'label'    => __( 'Footer Widget Area', 'newgenn' ),
	'description' => sprintf(__('Select widgets, Goto <a href="%1$s"target="_blank"> Customizer </a> => Widgets','newgenn'),admin_url('customize.php') ),
	'section'  => 'footer',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' ) 
	),
	'default'  => 'on',
) );
/* Choose No.Of Footer area */
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'footer_widgets_count',
	'label'    => __( 'Choose No.of widget area you want in footer', 'newgenn' ),
	'section'  => 'footer',
	'type'     => 'radio-buttonset',
	'choices' => array(
		1  => esc_attr__( '1', 'newgenn' ),
		2  => esc_attr__( '2', 'newgenn' ),
		3  => esc_attr__( '3', 'newgenn' ),
		4  => esc_attr__( '4', 'newgenn' ),
	),
	'default'  => 4,
) );

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'copyright',
	'label'    => __( 'Footer Copyright Text', 'newgenn' ),
	'section'  => 'footer',
	'type'     => 'textarea',
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'footer_top_margin',
	'label'    => __( 'Footer Top Margin', 'newgenn' ),
	'description' => __('Select the top margin of footer in pixels','newgenn'),
	'section'  => 'footer',
	'type'     => 'number',
	'choices' => array(
		'min' => 1,
		'max' => 1000,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.site-footer',
			'property' => 'margin-top',
			'units' => 'px',
		),
	),
	'default'  => 0,
) );

/* CUSTOM FOOTER BACKGROUND IMAGE 
footer background image section  */

Newgenn_Kirki::add_section( 'footer_image', array(
	'title'          => __( 'Footer Image','newgenn' ),
	'description'    => __( 'Custom Footer Image options', 'newgenn'),
	'panel'          => 'footer_panel', // Not typically needed.
) );

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'footer_bg_image',
	'label'    => __( 'Upload Footer Background Image', 'newgenn' ),
	'section'  => 'footer_image',
	'type'     => 'upload',
	'default'  => '',
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-image',
		),
	),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'footer_bg_size',
	'label'    => __( 'Footer Background Size', 'newgenn' ),
	'section'  => 'footer_image',
	'type'     => 'radio-buttonset',
    'choices' => array(
		'cover'  => esc_attr__( 'Cover', 'newgenn' ),
		'contain' => esc_attr__( 'Contain', 'newgenn' ),
		'auto'  => esc_attr__( 'Auto', 'newgenn' ),
		'inherit'  => esc_attr__( 'Inherit', 'newgenn' ),
	),
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-size',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'footer_bg_image',
			'operator' => '=',
			'value'    => true,
		),
	),
	'default'  => 'cover',
	'tooltip' => __('Footer Background Image Size','newgenn'),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'footer_bg_repeat',
	'label'    => __( 'Footer Background Repeat', 'newgenn' ),
	'section'  => 'footer_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'no-repeat' => esc_attr__('No Repeat', 'newgenn'),
        'repeat' => esc_attr__('Repeat', 'newgenn'),
        'repeat-x' => esc_attr__('Repeat Horizontally','newgenn'),
        'repeat-y' => esc_attr__('Repeat Vertically','newgenn'),
	),
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-repeat',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'footer_bg_image',
			'operator' => '=',
			'value'    => true,
		),
	),
	'default'  => 'repeat',  
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'footer_bg_position',
	'label'    => __( 'Footer Background Position', 'newgenn' ),
	'section'  => 'footer_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'center top' => esc_attr__('Center Top', 'newgenn'),
        'center center' => esc_attr__('Center Center', 'newgenn'),
        'center bottom' => esc_attr__('Center Bottom', 'newgenn'),
        'left top' => esc_attr__('Left Top', 'newgenn'),
        'left center' => esc_attr__('Left Center', 'newgenn'),
        'left bottom' => esc_attr__('Left Bottom', 'newgenn'),
        'right top' => esc_attr__('Right Top', 'newgenn'),
        'right center' => esc_attr__('Right Center', 'newgenn'),
        'right bottom' => esc_attr__('Right Bottom', 'newgenn'),
	),
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-position',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'footer_bg_image',
			'operator' => '=',
			'value'    => true,
		),
	),
	'default'  => 'center center',  
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'footer_bg_attachment',
	'label'    => __( 'Footer Background Attachment', 'newgenn' ),
	'section'  => 'footer_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'scroll' => esc_attr__('Scroll', 'newgenn'),
        'fixed' => esc_attr__('Fixed', 'newgenn'),
	),
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-attachment',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'footer_bg_image',
			'operator' => '=',
			'value'    => true,
		),
	),
	'default'  => 'scroll',  
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'footer_overlay',
	'label'    => __( 'Enable Footer( Background ) Overlay', 'newgenn' ),
	'section'  => 'footer_image',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' )
	),
	'default'  => 'off',
) );
  
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'footer_overlay_color',
	'label'    => __( 'Footer Overlay ( Background )color', 'newgenn' ),
	'section'  => 'footer_image',
	'type'     => 'color',
	'choices'  => array(
	    'alpha' => true,
	),
	'default'  => '#E5493A', 
	'active_callback' => array(
		array(
			'setting'  => 'footer_overlay',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output'   => array(
		array(
			'element'  => '.overlay-footer',
			'property' => 'background-color',
		),
	),
) );

//  slider panel //

Newgenn_Kirki::add_panel( 'slider_panel', array(   
	'title'       => __( 'Slider Settings', 'newgenn' ),  
	'description' => __( 'Flex slider related options', 'newgenn' ), 
	'priority'    => 11,    
) );

//  flexslider section  //

Newgenn_Kirki::add_section( 'flex_caption_section', array(
	'title'          => __( 'Flexcaption Settings','newgenn' ),
	'description'    => __( 'Flexcaption Related Options', 'newgenn'),
	'panel'          => 'slider_panel', // Not typically needed.
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'enable_flex_caption_edit',
	'label'    => __( 'Enable Custom Flexcaption Settings', 'newgenn' ),
	'section'  => 'flex_caption_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' ) 
	),
	'default'  => 'off',
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexcaption_bg',
	'label'    => __( 'Select Flexcaption Background Color', 'newgenn' ),
	'section'  => 'flex_caption_section',
	'type'     => 'color',
	'default'  => 'rgba(255, 255, 255, 0.7)',
	'choices'  => array(
	    'alpha' => true,
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .flex-caption h1, .flexslider .flex-caption h2,
							 .flexslider .flex-caption h3, .flexslider .flex-caption h4, .flexslider .flex-caption h5, 
							 .flexslider .flex-caption h6, 
							.flexslider .flex-caption p, .flexslider .flex-caption li,
							 .flexslider .flex-caption a',
			'property' => 'background-color',
			'suffix' => '!important',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexcaption_align',
	'label'    => __( 'Select Flexcaption Alignment', 'newgenn' ),
	'section'  => 'flex_caption_section',
	'type'     => 'select',
	'default'  => 'left',
	'choices' => array(
		'left' => esc_attr__( 'Left', 'newgenn' ),
		'right' => esc_attr__( 'Right', 'newgenn' ),
		'center' => esc_attr__( 'Center', 'newgenn' ),
		'justify' => esc_attr__( 'Justify', 'newgenn' ),
	),
	'output'   => array(
		array(
			'element'  => '.home .flexslider .slides .flex-caption p,.home .flexslider .slides .flex-caption h1, .home .flexslider .slides .flex-caption h2, .home .flexslider .slides .flex-caption h3, .home .flexslider .slides .flex-caption h4, .home .flexslider .slides .flex-caption h5, .home .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption,.flexslider .slides .flex-caption h1, .flexslider .slides .flex-caption h2, .flexslider .slides .flex-caption h3, .flexslider .slides .flex-caption h4, .flexslider .slides .flex-caption h5, .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption p,.flexslider .slides .flex-caption',
			'property' => 'text-align',
			//'suffix' => '!important',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),

) );
 Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexcaption_bg_position',
	'label'    => __( 'Select Flexcaption Background Horizontal Position', 'newgenn' ),
	'tooltip' => __('Select how far from left, Default value Left = 0( in % )','newgenn'),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '0',
	'choices'     => array(
		'min'  => -10,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'left',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),

) ); 
 Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexcaption_bg_vertical_position',
	'label'    => __( 'Select Flexcaption Background Vertical Position', 'newgenn' ),
	'tooltip' => __('Select how far from bottom, Default value Bottom = 5 ( in % )','newgenn'),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '5',
	'choices'     => array(
		'min'  => -10,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'bottom',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),

) ); 
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexcaption_bg_width',
	'label'    => __( 'Select Flexcaption Background Width', 'newgenn' ),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '50',
	'tooltip' => __('Select Flexcaption Background Width , Default width value 50','newgenn'),
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .flex-caption h1, .flexslider .flex-caption h2, .flexslider .flex-caption h3, .flexslider .flex-caption h4, .flexslider .flex-caption h5, .flexslider .flex-caption h6, .flexslider .flex-caption p, .flexslider .flex-caption li, .flexslider .flex-caption a',
			'property' => 'width',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),

) ); 
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexcaption_responsive_bg_width',
	'label'    => __( 'Select Responsive Flexcaption Background Width', 'newgenn' ),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '100',
	'tooltip' => __('Select Responsive Flexcaption Background Width, Default width value 100 ( This value will apply for max-width: 768px )','newgenn'),
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'width',
			'media_query' => '@media (max-width: 768px)',
			'value_pattern' => 'calc($%)',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),

) );  
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexcaption_color',
	'label'    => __( 'Select Flexcaption Font Color', 'newgenn' ),
	'section'  => 'flex_caption_section',
	'type'     => 'color',
	'default'  => 'rgba(0,0,0,1)', 
	'choices'  => array(
	    'alpha' => true,
	),
	'output'   => array(   
		array(
			'element'  => '.flex-caption,.home .flexslider .slides .flex-caption p,
			.home .flexslider .slides .flex-caption p a,
			.flexslider .slides .flex-caption p,.home .flexslider .slides .flex-caption h1,
			 .home .flexslider .slides .flex-caption h2, .home .flexslider .slides .flex-caption h3,
			  .home .flexslider .slides .flex-caption h4, .home .flexslider .slides .flex-caption h5, 
			  .home .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption h1,.flexslider .slides .flex-caption h2,.flexslider .slides .flex-caption h3,.flexslider .slides .flex-caption h4,.flexslider .slides .flex-caption h5,.flexslider .slides .flex-caption h6',
			'property' => 'color',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),

) );
 if( class_exists( 'WooCommerce' ) ) {
	Newgenn_Kirki::add_section( 'woocommerce_section', array(
		'title'          => __( 'WooCommerce','newgenn' ),
		'description'    => __( 'Theme options related to woocommerce', 'newgenn'),
		'priority'       => 11, 

		'theme_supports' => '', // Rarely needed.
	) );
	Newgenn_Kirki::add_field( 'woocommerce', array(
		'settings' => 'woocommerce_sidebar',
		'label'    => __( 'Enable Woocommerce Sidebar', 'newgenn' ),
		'description' => __('Enable Sidebar for shop page','newgenn'),
		'section'  => 'woocommerce_section',
		'type'     => 'switch',
		'choices' => array(
			'on'  => esc_attr__( 'Enable', 'newgenn' ),
			'off' => esc_attr__( 'Disable', 'newgenn' ) 
		),

		'default'  => 'on',
	) );
}
	
// background color ( rename )

Newgenn_Kirki::add_section( 'colors', array(
	'title'          => __( 'Background Color','newgenn' ),
	'description'    => __( 'This will affect overall site background color', 'newgenn'),
	//'panel'          => 'skin_color_panel', // Not typically needed.
	'priority' => 11,
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'general_background_color',
	'label'    => __( 'General Background Color', 'newgenn' ),
	'section'  => 'colors',
	'type'     => 'color',
	'choices'  => array(
	    'alpha' => true,
	),
	'default'  => '#ffffff',
	'output'   => array(
		array(
			'element'  => 'body',
			'property' => 'background-color',
		),
	),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'content_background_color',
	'label'    => __( 'Content Background Color', 'newgenn' ),
	'section'  => 'colors',
	'type'     => 'color',
	'description' => __('when you are select boxed layout content background color will reflect the grid area','newgenn'), 
	"choices['alpha']" => true, 
	'default'  => '#ffffff',
	'output'   => array(
		array(
			'element'  => '.boxed-container',
			'property' => 'background-color',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'site-style',
			'operator' => '==',
			'value'    => 'boxed',
		),
	),
) );

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'general_background_image',
	'label'    => __( 'General Background Image', 'newgenn' ),
	'section'  => 'background_image',
	'type'     => 'upload',
	'default'  => '',
	'output'   => array(
		array(
			'element'  => 'body',
			'property' => 'background-image',
		),
	),
) );

// background image ( general & boxed layout ) //


Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'general_background_repeat',
	'label'    => __( 'General Background Repeat', 'newgenn' ),
	'section'  => 'background_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'no-repeat' => esc_attr__('No Repeat', 'newgenn'),
        'repeat' => esc_attr__('Repeat', 'newgenn'),
        'repeat-x' => esc_attr__('Repeat Horizontally','newgenn'),
        'repeat-y' => esc_attr__('Repeat Vertically','newgenn'),
	),
	'output'   => array(
		array(
			'element'  => 'body',
			'property' => 'background-repeat',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'general_background_image',
			'operator' => '==',
			'value'    => true,
		),
	),
	'default'  => 'repeat',  
) );

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'general_background_size',
	'label'    => __( 'General Background Size', 'newgenn' ),
	'section'  => 'background_image',
	'type'     => 'select',
	'multiple'    => 1,
    'choices' => array(
		'cover'  => esc_attr__( 'Cover', 'newgenn' ),
		'contain' => esc_attr__( 'Contain', 'newgenn' ),
		'auto'  => esc_attr__( 'Auto', 'newgenn' ),
		'inherit'  => esc_attr__( 'Inherit', 'newgenn' ),
	),
	'output'   => array(
		array(
			'element'  => 'body',
			'property' => 'background-size',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'general_background_image',
			'operator' => '==',
			'value'    => true,
		),
	),
	'default'  => 'cover',  
) );

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'general_background_attachment',
	'label'    => __( 'General Background Attachment', 'newgenn' ),
	'section'  => 'background_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'scroll' => esc_attr__('Scroll', 'newgenn'),
        'fixed' => esc_attr__('Fixed', 'newgenn'),
	),
	'output'   => array(
		array(
			'element'  => 'body',
			'property' => 'background-attachment',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'general_background_image',
			'operator' => '==',
			'value'    => true,
		),
	),
	'default'  => 'fixed',  
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'general_background_position',
	'label'    => __( 'General Background Position', 'newgenn' ),
	'section'  => 'background_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'center top' => esc_attr__('Center Top', 'newgenn'),
        'center center' => esc_attr__('Center Center', 'newgenn'),
        'center bottom' => esc_attr__('Center Bottom', 'newgenn'),
        'left top' => esc_attr__('Left Top', 'newgenn'),
        'left center' => esc_attr__('Left Center', 'newgenn'),
        'left bottom' => esc_attr__('Left Bottom', 'newgenn'),
        'right top' => esc_attr__('Right Top', 'newgenn'),
        'right center' => esc_attr__('Right Center', 'newgenn'),
        'right bottom' => esc_attr__('Right Bottom', 'newgenn'),
	),
	'output'   => array(
		array(
			'element'  => 'body',
			'property' => 'background-position',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'general_background_image', 
			'operator' => '==',
			'value'    => true,
		),
	),
	'default'  => 'center top',  
) );


/* CONTENT BACKGROUND ( boxed background image )*/

Newgenn_Kirki::add_field( 'newgenn', array(  
	'settings' => 'content_background_image',
	'label'    => __( 'Content Background Image', 'newgenn' ),
	'description' => __('when you are select boxed layout content background image will reflect the grid area','newgenn'),
	'section'  => 'background_image',
	'type'     => 'upload',
	'default'  => '',
	'output'   => array(
		array(
			'element'  => '.boxed-container',
			'property' => 'background-image',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'site-style',
			'operator' => '==',
			'value'    => 'boxed',
		),
	),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'content_background_repeat',
	'label'    => __( 'Content Background Repeat', 'newgenn' ),
	'section'  => 'background_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'no-repeat' => esc_attr__('No Repeat', 'newgenn'),
        'repeat' => esc_attr__('Repeat', 'newgenn'),
        'repeat-x' => esc_attr__('Repeat Horizontally','newgenn'),
        'repeat-y' => esc_attr__('Repeat Vertically','newgenn'),
	),
	'output'   => array(
		array(
			'element'  => '.boxed-container',
			'property' => 'background-repeat',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'site-style',
			'operator' => '==',
			'value'    => 'boxed',
		),
		array(
			'setting'  => 'content_background_image', 
			'operator' => '==',
			'value'    => true,
		),
	),
	'default'  => 'repeat',  
) );

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'content_background_size',
	'label'    => __( 'Content Background Size', 'newgenn' ),
	'section'  => 'background_image',
	'type'     => 'select',
	'multiple'    => 1,
    'choices' => array(
		'cover'  => esc_attr__( 'Cover', 'newgenn' ),
		'contain' => esc_attr__( 'Contain', 'newgenn' ),
		'auto'  => esc_attr__( 'Auto', 'newgenn' ),
		'inherit'  => esc_attr__( 'Inherit', 'newgenn' ),
	),
	'output'   => array(
		array(
			'element'  => '.boxed-container',
			'property' => 'background-size',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'site-style',
			'operator' => '==',
			'value'    => 'boxed',
		),
		array(
			'setting'  => 'content_background_image', 
			'operator' => '==',
			'value'    => true,
		),
	),
	'default'  => 'cover',  
) );

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'content_background_attachment',
	'label'    => __( 'Content Background Attachment', 'newgenn' ),
	'section'  => 'background_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'scroll' => esc_attr__('Scroll', 'newgenn'),
        'fixed' => esc_attr__('Fixed', 'newgenn'),
	),
	'output'   => array(
		array(
			'element'  => '.boxed-container',
			'property' => 'background-attachment',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'site-style',
			'operator' => '==',
			'value'    => 'boxed',
		),
		array(
			'setting'  => 'content_background_image', 
			'operator' => '==',
			'value'    => true,
		),
	),
	'default'  => 'fixed',  
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'content_background_position',
	'label'    => __( 'Content Background Position', 'newgenn' ),
	'section'  => 'background_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'center top' => esc_attr__('Center Top', 'newgenn'),
        'center center' => esc_attr__('Center Center', 'newgenn'),
        'center bottom' => esc_attr__('Center Bottom', 'newgenn'),
        'left top' => esc_attr__('Left Top', 'newgenn'),
        'left center' => esc_attr__('Left Center', 'newgenn'),
        'left bottom' => esc_attr__('Left Bottom', 'newgenn'),
        'right top' => esc_attr__('Right Top', 'newgenn'),
        'right center' => esc_attr__('Right Center', 'newgenn'),
        'right bottom' => esc_attr__('Right Bottom', 'newgenn'),
	),
	'output'   => array(
		array(
			'element'  => '.boxed-container',
			'property' => 'background-position',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'site-style',
			'operator' => '==',
			'value'    => 'boxed',
		),
		array(
			'setting'  => 'content_background_image', 
			'operator' => '==',
			'value'    => true,
		),
	),
	'default'  => 'center top',  
) );

do_action('wbls-newgenn_pro_customizer_options');
do_action('newgenn_child_customizer_options');
