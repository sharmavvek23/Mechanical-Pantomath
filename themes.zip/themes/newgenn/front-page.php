<?php
/**
 * The front page template file.
 *
 *
 * @package Newgenn
 */
	if( 'posts' == get_option( 'show_on_front' ) ) {
	     get_template_part('home');
	} else {

get_header(); 
	if ( get_theme_mod('page-builder' ) ) {   
		if( get_theme_mod('flexslider') ) {   
			echo do_shortcode( get_theme_mod('flexslider'));
		} ?>
   
		<div id="content" class="site-content">
		   <div class="container"> 
			<?php  if( get_theme_mod('home_sidebar',false ) ) { ?>
				<div id="primary" class="content-area eleven columns">
			<?php }else { ?>
			    <div id="primary" class="content-area sixteen columns">
			<?php } ?>  
				<main id="main" class="site-main" role="main">
					<?php
						while ( have_posts() ) : the_post();
							the_content();
						endwhile;
					?>
			     </main><!-- #main -->
		     </div><!-- #primary -->
<?php	} else {
	       if( get_theme_mod('enable_slider',true) ) { 
	           get_template_part('category-slider');
            }
	?>
		<div id="content" class="site-content free-home">
			<div class="container">		
			<?php  if( get_theme_mod('home_sidebar',false ) ) { ?>
						<div id="primary" class="content-area eleven columns">
					<?php }else { ?>
					    <div id="primary" class="content-area sixteen columns">
					<?php } ?>
				<main id="main" class="site-main" role="main">

				<?php
			do_action('newgenn_service_content_before'); 
			if(get_theme_mod('enable_service',true) ) { 
					$service = get_theme_mod('service_count',4 );
						    $service_pages = array();
						    for ( $i = 1 ; $i <= $service ; $i++ ) {
								$service_page = absint(get_theme_mod('service_'.$i));
								if( $service_page ){
		                            $service_pages[] = $service_page;
								}
						    }
					if( $service_pages && !empty( $service_pages ) ) {
						$args = array(
							'post_type' => 'page',
							'post__in' => $service_pages,
							'posts_per_page' => -1 ,
							'orderby' => 'post__in'
						);
					} elseif( current_user_can('manage_options') )  { ?>
						<div class="services-wrapper clearfix">
						    <div class="four columns">
						    	<img src="<?php echo get_template_directory_uri(); ?>/images/page1.png" />								    		
								<h4><?php _e('Responsive Layout','newgenn');?></h4>
								<?php echo sprintf('<p> %1$s <a href="%2$s" target="_blank"> %3$s</a> %4$s</p>',__('You haven\'t created any service page yet. Create Page. Go to','newgenn'), esc_url(admin_url('customize.php')), __('Customizer','newgenn'),__('and click newgenn Options => Home => Service Section #1 and select page from  dropdown page list.','newgenn'));?>					    	
						    </div>
						    <div class="four columns">						 
								<img src="<?php echo get_template_directory_uri(); ?>/images/page2.png" />								    		
								<h4><?php _e('Awesome Sliders','newgenn');?></h4>
								<?php echo sprintf('<p> %1$s <a href="%2$s" target="_blank"> %3$s</a> %4$s</p>',__('You haven\'t created any service page yet. Create Page. Go to','newgenn'), esc_url(admin_url('customize.php')), __('Customizer','newgenn'),__('and click newgenn Options => Home => Service Section #2 and select page from  dropdown page list.','newgenn'));?>					    	
			   				</div> 
			   				<div class="four columns">						 
								<img src="<?php echo get_template_directory_uri(); ?>/images/page3.png" />								    		
								<h4><?php _e('Retina Ready','newgenn');?></h4>
								<?php echo sprintf('<p> %1$s <a href="%2$s" target="_blank"> %3$s</a> %4$s</p>',__('You haven\'t created any service page yet. Create Page. Go to','newgenn'), esc_url(admin_url('customize.php')), __('Customizer','newgenn'),__('and click newgenn Options => Home => Service Section #3 and select page from  dropdown page list.','newgenn'));?>						    	
			   				</div> 
			   				<div class="four columns">						 
								<img src="<?php echo get_template_directory_uri(); ?>/images/page1.png" />								    		
								<h4><?php _e('Shortcodes','newgenn');?></h4>
								<?php echo sprintf('<p> %1$s <a href="%2$s" target="_blank"> %3$s</a> %4$s</p>',__('You haven\'t created any service page yet. Create Page. Go to','newgenn'), esc_url(admin_url('customize.php')), __('Customizer','newgenn'),__('and click newgenn Options => Home => Service Section #4 and select page from  dropdown page list.','newgenn'));?>					    	
			   				</div> 
						</div>	
				<?php }
			   	if( isset($args) ) :
					$query = new WP_Query($args);   
					if( $query->have_posts()) : ?>
						<div class="services-wrapper row">
							<?php while($query->have_posts()) :
								$query->the_post(); ?>
							     <a class="service-page" href="<?php echo esc_url( get_permalink() ); ?>" rel="bookmark">  
								     <div class="four columns">
								    	<?php if( has_post_thumbnail() ) : ?>
								    		<?php the_post_thumbnail('newgenn_home_page_img'); ?>
								    	<?php endif; ?>
								    	<?php the_title( '<h4>', '</h4>' ); ?>
								    	<?php the_content(); ?> 
								    </div> 
							    </a> 
							<?php endwhile; ?>
					        
						</div>
					<?php endif; ?>
					<?php  
						$query = null;
						wp_reset_postdata();
				endif;
			} 
					
			 do_action('newgenn_service_content_after');
			if(get_theme_mod('enable_recent_post_service',true) ) {
				newgenn_recent_posts(); 
			}
		
	 if( get_theme_mod('enable_home_default_content',false ) ) {  ?>
			<div class="container default-home-page">
				<?php
				while ( have_posts() ) : the_post();       
					the_content();
				endwhile;
		       ?>
	        </div>    
      <?php } ?>
		</main><!-- #main -->
	</div><!-- #primary -->

<?php }
if( get_theme_mod('home_sidebar',false ) ) { 
   get_sidebar();
}
get_footer();
} ?>