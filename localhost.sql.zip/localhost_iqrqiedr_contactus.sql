--
-- Database: `iqrqiedr_contactus`
--
CREATE DATABASE IF NOT EXISTS `iqrqiedr_contactus` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `iqrqiedr_contactus`;

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `id` int(11) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `message` varchar(500) NOT NULL,
  `mobno` bigint(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contactus`
--

INSERT INTO `contactus` (`id`, `name`, `email`, `subject`, `message`, `mobno`) VALUES
(58, 'Mayank', 'mnkpat1995@gmail.com', 'Check', 'Check 13', 20210329225416),
(59, 'Mayank', 'mnkpat1995@gmail.com', 'Check', 'Check 14', NULL),
(60, 'Mayank', 'mnkpat1995@gmail.com', 'Check', 'Check 14', NULL),
(61, 'Mayank', 'mnkpat1995@gmail.com', 'Check', 'Check 14', NULL),
(62, 'Mayank', 'mnkpat1995@gmail.com', 'Check', 'Check 14', NULL),
(63, 'Mayank', 'mnkpat1995@gmail.com', 'Check', 'Check 20', NULL),
(64, 'Mayank', 'mnkpat1995@gmail.com', 'Check', 'Check 21', NULL),
(65, 'Mayank', 'mnkpat1995@gmail.com', 'Check', 'Check 22', NULL),
(66, 'Mayank', 'mnkpat1995@gmail.com', 'Check', 'Check 23', NULL),
(67, 'Mayank', 'mnkpat1995@gmail.com', 'Check', 'Check 23', NULL),
(68, 'Mayank', 'mnkpat1995@gmail.com', 'Check', 'Check 30', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE `info` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `subject` varchar(200) DEFAULT NULL,
  `mobno` bigint(10) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `qualification` varchar(100) DEFAULT NULL,
  `guidefor` varchar(50) DEFAULT NULL,
  `guidemode` varchar(50) DEFAULT NULL,
  `discipline` varchar(50) DEFAULT NULL,
  `profession` varchar(50) DEFAULT NULL,
  `message` varchar(500) DEFAULT NULL,
  `datetime` datetime NOT NULL DEFAULT current_timestamp(),
  `remarks` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`id`, `name`, `email`, `subject`, `mobno`, `gender`, `qualification`, `guidefor`, `guidemode`, `discipline`, `profession`, `message`, `datetime`, `remarks`) VALUES
(1, 'Mayank', 'mnkpat1995@gmail.com', '', 9763328494, NULL, NULL, 'Exam', 'Phone', NULL, NULL, 'Good Luck', '2021-03-30 00:43:58', NULL),
(2, 'Pravin', 'pravins5279@gmail.com', '', 8691805688, NULL, NULL, 'Exam', 'Phone', NULL, NULL, 'Help', '2021-03-30 19:51:16', NULL),
(3, 'Omkar', 'omkarmraut@gmail.com', '', 9730460138, NULL, NULL, 'Interview', 'Email', NULL, NULL, 'I want questions for ISRO and BARC as much as possible so that studying only that questions will be enough. Pls provide me question bank. ', '2021-03-30 20:42:31', NULL),
(15, 'Animesh', 'animesh184@gmail.com', '', 7980678438, NULL, NULL, 'Interview', 'Any', NULL, NULL, 'Sir,I am 2019 passout.My B.Tech CGPA is 7.84 and my Gate Score is 655(ME) and rank 2909 in year 2021.I want to prepare for MS written and interviews for IITs.', '2021-03-31 11:33:24', NULL),
(16, NULL, 'nikhilreddy04.kudage@gmail.com', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-04-03 01:04:38', NULL),
(17, 'FARHAN JALALI', 'farhan_jalali@ymail.com', '', 8073465547, NULL, NULL, 'Career', 'Any', NULL, NULL, 'Dear Sir\r\n                I received your website recommendation from one of my friend, hoping that my doubt gets clear. I am Mechanical engineer having 4 years of experience as a Rotating equipment technician having gulf experienced in oil and gas industry. \r\n   i wanted to go ahead as a rotating design engineer since  I have field experience it will make me easier to achieve or i should go as a reliabity engineer condition monitoring.\r\n   please guide me, which is a best career\r\n       ', '2021-04-03 20:37:57', NULL),
(18, NULL, 'sairamadaboina45@gmail.com', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-04-04 15:18:24', NULL),
(19, NULL, 'sairamadaboina45@gmail.com', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-04-04 15:18:36', NULL),
(20, NULL, 'vedtheboss1998@gmail.com', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-04-05 15:10:42', NULL),
(21, NULL, 'vedtheboss1998@gmail.com', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-04-05 15:10:51', NULL),
(22, NULL, 'sudhaaero3@gmail.com', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-04-12 08:37:35', NULL),
(23, NULL, 'sudhaaero3@gmail.com', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-04-12 08:37:50', NULL),
(24, NULL, 'pavandinesh99@gmail.com', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-04-18 11:50:48', NULL),
(25, 'Subhadeep Nayak', 'subhadeepnayak12@gmail.com', '', 7063699453, NULL, NULL, 'Exam', 'Any', NULL, NULL, 'Sir I am continiously failing to crack any written exam for 2 years. I have filled form of HPCL , HAL , and 2 other psu s . My problem is everying jumble up in my mind during preparation and exam. I need guidance. Please sir help me.', '2021-04-24 00:41:53', NULL),
(26, 'Subhadeep Nayak', 'subhadeepnayak12@gmail.com', '', 7063699453, NULL, NULL, 'Exam', 'Any', NULL, NULL, 'Sir I am continiously failing to crack any written exam for 2 years. I have filled form of HPCL , HAL , and 2 other psu s . My problem is everying jumble up in my mind during preparation and exam. I need guidance. Please sir help me.', '2021-04-24 00:42:51', NULL),
(27, NULL, 'mnkpatidar98@gmail.com', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-05-04 14:53:04', NULL),
(28, NULL, 'jiteshkachavay.jk@gmsil.com', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-05-12 15:35:13', NULL),
(29, NULL, 'rajendrakumarpaul@gmail.com', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-05-19 17:32:03', NULL),
(30, NULL, 'rajendrakumarpaul@gmail.com', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-05-19 17:32:10', NULL),
(31, NULL, 'Niko.Moen@yahoo.com', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-05-22 19:42:53', NULL),
(32, 'PONNADA KRANTHI KIRAN', 'ironkiran11@gmail.com', '', 7702242272, NULL, NULL, 'Interview', 'Any', NULL, NULL, 'I am preparing for NPCIL interview and expecting other calls from PSUs.I believe with my existing GATE score I may qualify to BARC interview too', '2021-05-22 21:17:00', NULL),
(33, 'Dhiraj Kinholkar', 'kinholkardhiraj7@gmail.com', '', 7387139367, NULL, NULL, 'Exam', 'Email', NULL, NULL, 'I want study material for government exam like BARC ISRO ', '2021-05-28 20:36:40', NULL),
(34, NULL, 'coolchaudharirahul@gmail.com', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-05-30 19:18:08', NULL),
(35, NULL, 'zrashidhashmi07@gmail.com', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-06-12 10:00:11', NULL),
(36, NULL, 'zrashidhashmi07@gmail.com', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-06-12 10:00:17', NULL),
(37, NULL, 'zrashidhashmi07@gmail.com', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-06-12 10:00:20', NULL),
(38, NULL, 'shubham14034@gmail.com', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-06-13 03:09:37', NULL),
(86, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '2021-06-24 21:07:55', NULL),
(87, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '2021-06-27 04:13:01', NULL),
(88, 'BYREDDY S M', 'byreddysm498@gmail.com', NULL, 918073624782, NULL, NULL, '', 'Email', 'Mechanical Engineering', NULL, 'I completed my engineering in 2019 and done 1 year apperentice training.\r\n8 have been searching for a job since a long while but not getting interview calls itself in mechanical field.\r\nIam confused about weather i should go in core or shift to it firm.', '2021-07-01 07:13:18', NULL),
(89, 'YOGESH JADHAV', 'yojadhav96@gmail.com', NULL, 9503557586, NULL, NULL, 'Career', 'Email', 'Mechanical Engineering', NULL, '', '2021-07-05 23:04:23', NULL),
(90, NULL, 'ayushsachan281093@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-07-11 23:22:36', NULL),
(91, NULL, 'ayushsachan281093@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-07-11 23:22:40', NULL),
(92, NULL, 'ayazshaikh0925@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-07-12 19:37:02', NULL),
(93, 'ACHARYA JIGARKUMAR SHAILESBHAI', 'acharyajigar319012@gmail.com', NULL, 9033567732, NULL, NULL, '', 'Any', 'Mechanical Engineering', NULL, 'I have Complet my Diploma and BE in mechanical engineering.\r\n\r\nI have prepared for SSC JE , NPCIL, BARC, ISRO\r\nexamination.\r\n\r\nSo please guide me.', '2021-07-13 23:02:50', NULL),
(94, 'ACHARYA JIGARKUMAR SHAILESBHAI', 'acharyajigar319012@gmail.com', NULL, 9033567732, NULL, NULL, '', 'Any', 'Mechanical Engineering', NULL, 'I have Complet my Diploma and BE in mechanical engineering.\r\n\r\nI have prepared for SSC JE , NPCIL, BARC, ISRO\r\nexamination.\r\n\r\nSo please guide me.', '2021-07-13 23:03:01', NULL),
(95, NULL, 'pravins5279@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-07-15 23:38:33', NULL),
(96, 'Ranit Gon', 'ranitgon80@gmail.com', NULL, 919547848468, NULL, NULL, 'Exam', 'Any', 'Mechanical Engineering', NULL, '', '2021-07-16 16:16:06', NULL),
(97, 'Ranit Gon', 'ranitgon80@gmail.com', NULL, 919547848468, NULL, NULL, 'Exam', 'Any', 'Mechanical Engineering', NULL, '', '2021-07-16 16:16:20', NULL),
(98, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '2021-07-19 18:14:48', NULL),
(99, 'Tondapu Naga sai Kumar Reddy', 'nagasaikumarreddy311@gmail.com', NULL, 6302202759, NULL, NULL, '', 'Email', 'Mechanical Engineering', NULL, 'I want to prepare for IGcar . I completed my diploma in mechanical engineering', '2021-07-21 10:41:35', NULL),
(100, 'Praveen Kumar', 'praveenkumar150896@gmail.com', NULL, 9634987170, NULL, NULL, 'Interview', 'Email', 'Mechanical Engineering', NULL, '', '2021-07-21 13:07:32', NULL),
(101, 'Swaraj Deep Sharma', 'swarajdeepsharma16@gmail.com', NULL, 8016260264, NULL, NULL, 'Exam', 'Any', 'Mechanical Engineering', NULL, 'I want to prepare for upcoming PSU examinations like BARC, ISRO, HPCL, HAL.\r\nI need guidance for strategy and solving questions under 1 minute or 30sec. What are the Sources, Study materials and strategy for BARC, ISRO, HPCL,HAL if clearing this exam within one year.\r\nHow to increase speed of solving questions accurately.\r\n\r\nI get exhausted snd sometimes lazy to solve previous year questions as they are so many.\r\n\r\nSo I request Mechanical PANTOMATH to please help me regarding this matter.', '2021-07-21 18:14:36', NULL),
(102, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '2021-07-22 00:14:37', NULL),
(103, 'sunil kumar', 'sk0538877@gmail.com', NULL, 9485869273, NULL, NULL, 'Exam', 'Any', 'Mechanical Engineering', NULL, 'gate 2021 rank 1625 have no clue what to do now ', '2021-07-24 10:06:14', NULL),
(104, 'KARNAJIT DEBNATH', 'debnathkarnajit03@gmail.com', NULL, 8838947982, NULL, NULL, 'Interview', 'Any', 'Mechanical Engineering', NULL, '', '2021-07-24 14:28:29', NULL),
(105, 'Swarn Pushpak', 'swarnthepushpak@gmail.com', NULL, 8340549608, NULL, NULL, 'Exam', 'Any', 'Mechanical Engineering', NULL, '', '2021-07-24 15:21:37', NULL),
(106, 'Ashutosh Yadav', 'ashutoshme0030@gmail.com', NULL, 9569052506, NULL, NULL, 'Exam', 'Phone', 'Mechanical Engineering', NULL, '', '2021-07-28 09:08:30', NULL),
(107, 'Ashutosh Yadav', 'ashutoshme0030@gmail.com', NULL, 9569052506, NULL, NULL, 'Exam', 'Phone', 'Mechanical Engineering', NULL, '', '2021-07-28 09:09:00', NULL),
(108, 'Nityaprakash Yogi', 'nityaprakash30@gmail.com', NULL, 7015092660, NULL, NULL, 'Interview', 'Phone', 'Mechanical Engineering', NULL, 'Hallo sir , I am Nityaprakash yogi from sgi engineering college from kurukshetra university, I have completed my b. Tech in mechanical engineering and I want to crack   psu jobs , plz guide me interview or   how to crack with or without gate score...\r\n\r\n                                                  Thank you ðŸ™', '2021-07-29 11:02:45', NULL),
(109, 'Nityaprakash Yogi', 'nityaprakash30@gmail.com', NULL, 7015092660, NULL, NULL, 'Exam', 'Phone', 'Mechanical Engineering', NULL, 'Hallo sir , I am Nityaprakash yogi from sgi engineering college from kurukshetra university, I have completed my b. Tech in mechanical engineering and I want to crack   psu jobs , plz guide me interview or   how to crack with or without gate score...\r\n\r\n                                                  Thank you ðŸ™', '2021-07-29 11:03:11', NULL),
(110, 'Nityaprakash Yogi', 'nityaprakash30@gmail.com', NULL, 7015092660, NULL, NULL, 'Exam', 'Phone', 'Mechanical Engineering', NULL, 'Hallo sir , I am Nityaprakash yogi from sgi engineering college from kurukshetra university, I have completed my b. Tech in mechanical engineering and I want to crack   psu jobs , plz guide me interview or   how to crack with or without gate score...\r\n\r\n                                                  Thank you ðŸ™', '2021-07-29 11:03:31', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contactus`
--
ALTER TABLE `contactus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contactus`
--
ALTER TABLE `contactus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `info`
--
ALTER TABLE `info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;
